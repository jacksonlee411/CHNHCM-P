# 中国大陆HCM图集

[返回总览](../README.md)。共53张目标设计图：5张综合概念、5张整体、20张业务模块、6张横向能力、9张联合流程、8张关键设计。每图都有SVG和Mermaid；点击SVG可放大查看。

本页只列独立China HCM目标设计。对象存在于目标图不表示已实现。模块图颜色仅表示职责：蓝色对象、橙色处理、灰色其他域/外部系统、绿色横向合同。

阅读主线：**L1整体业务架构 → L2领域概念 → L3模块设计 → L4关键设计**。先从G02总图定位业务区域，再按C编号展开；[对应关系与补充入口](../02-target-architecture.md#1-整体模块架构)说明跨域引用、招聘/服务及C05的横向范围。

本轮C01—C05及下级图已按HCM概念和DDD逐项修订；查看[阶段发现与闭合记录](../13-target-design-review.md)及[验证范围](../06-evidence-and-validation.md)。

## L1 整体业务架构

G02是总图；G03补充事实归属，G05补充DDD限界上下文。它们是整体层的不同视角。

G02分别展示服务/专业办理入口、业务区域、配置与权限支持、技术设施及授权分析。实线表示事实、建议或外部交换，虚线表示办理访问或支撑，具体含义以标签为准；业务核准及结果确认归所属域。

| 图 | SVG | Mermaid |
| --- | --- | --- |
| G02 整体业务架构与概念展开 | [查看](g02-target-domain-map.svg) | [源图](g02-target-domain-map.mmd) |
| G03 事实归属与依赖 | [查看](g03-fact-ownership.svg) | [源图](g03-fact-ownership.mmd) |
| G05 限界上下文地图 | [查看](g05-context-map.svg) | [源图](g05-context-map.mmd) |

## L2 领域概念架构（对标HCM颗粒度）

C01—C04按业务主题展开；C05贯穿各业务域。概念粒度和DDD关系说明见[概念架构](../12-concept-architecture.md)。

| 图 | SVG | Mermaid |
| --- | --- | --- |
| C01 核心人事与任职引用 | [查看](c01-core-hcm-concepts.svg) | [源图](c01-core-hcm-concepts.mmd) |
| C02 薪资领域概念 | [查看](c02-payroll-concepts.svg) | [源图](c02-payroll-concepts.mmd) |
| C03 时间缺勤与权益 | [查看](c03-time-absence-concepts.svg) | [源图](c03-time-absence-concepts.mmd) |
| C04 人才评价与发展 | [查看](c04-talent-concepts.svg) | [源图](c04-talent-concepts.mmd) |
| C05 引用适用权限与核准 | [查看](c05-reference-access-concepts.svg) | [源图](c05-reference-access-concepts.mmd) |

## L3 业务模块设计

| 图 | SVG | Mermaid |
| --- | --- | --- |
| M01 人员身份与个人资料 | [查看](m01.svg) | [编辑源文件](m01.mmd) |
| M02 企业、组织与地点 | [查看](m02.svg) | [编辑源文件](m02.mmd) |
| M03 职务、职级、职位与编制 | [查看](m03.svg) | [编辑源文件](m03.mmd) |
| M04 用工、任职与劳动合同 | [查看](m04.svg) | [编辑源文件](m04.mmd) |
| M05 招聘、录用与入职协同 | [查看](m05.svg) | [编辑源文件](m05.mmd) |
| M06 排班与工时制度 | [查看](m06.svg) | [编辑源文件](m06.mmd) |
| M07 考勤与实际工时 | [查看](m07.svg) | [编辑源文件](m07.mmd) |
| M08 休假、缺勤与权益账户 | [查看](m08.svg) | [编辑源文件](m08.mmd) |
| M09 薪酬体系、定薪与激励 | [查看](m09.svg) | [编辑源文件](m09.mmd) |
| M10 工资核算、累计与追溯 | [查看](m10.svg) | [编辑源文件](m10.mmd) |
| M11 个人所得税扣缴与申报 | [查看](m11.svg) | [编辑源文件](m11.mmd) |
| M12 社会保险与住房公积金 | [查看](m12.svg) | [编辑源文件](m12.mmd) |
| M13 企业福利 | [查看](m13.svg) | [编辑源文件](m13.mmd) |
| M14 工资支付与银行用途 | [查看](m14.svg) | [编辑源文件](m14.mmd) |
| M15 人工成本与财务衔接 | [查看](m15.svg) | [编辑源文件](m15.mmd) |
| M16 人才档案、技能与资格 | [查看](m16.svg) | [编辑源文件](m16.mmd) |
| M17 目标与绩效 | [查看](m17.svg) | [编辑源文件](m17.mmd) |
| M18 学习与发展 | [查看](m18.svg) | [编辑源文件](m18.mmd) |
| M19 人才盘点、人才池与继任 | [查看](m19.svg) | [编辑源文件](m19.mmd) |
| M20 员工经理服务与HR任务 | [查看](m20.svg) | [编辑源文件](m20.mmd) |

## L3 横向能力设计

| 图 | SVG | Mermaid |
| --- | --- | --- |
| X01 身份、有效期、修订与采用历史 | [查看](x01.svg) | [编辑源文件](x01.mmd) |
| X02 共享配置、适用范围、默认与政策版本 | [查看](x02.svg) | [编辑源文件](x02.mmd) |
| X03 身份权限与隐私 | [查看](x03.svg) | [编辑源文件](x03.mmd) |
| X04 任务、作业与人工核对 | [查看](x04.svg) | [编辑源文件](x04.mmd) |
| X05 导入导出与外部集成 | [查看](x05.svg) | [编辑源文件](x05.mmd) |
| X06 报表、指标与事实追溯 | [查看](x06.svg) | [编辑源文件](x06.mmd) |

## L4 关键对象、聚合与状态设计

| 图 | SVG | Mermaid |
| --- | --- | --- |
| G06 聚合与事务边界 | [查看](g06-aggregate-transactions.svg) | [源图](g06-aggregate-transactions.mmd) |
| E01 人员、关系、任职、合同与计薪 | [查看](e01-person-employment.svg) | [编辑源文件](e01-person-employment.mmd) |
| E02 法律实体及不同用途 | [查看](e02-legal-contexts.svg) | [编辑源文件](e02-legal-contexts.mmd) |
| E03 参缴、申报、扣收与资金 | [查看](e03-contribution-ledgers.svg) | [编辑源文件](e03-contribution-ledgers.mmd) |
| E04 生效、修订与采用 | [查看](e04-effective-adoption.svg) | [编辑源文件](e04-effective-adoption.mmd) |
| E05 账户身份、用途与付款 | [查看](e05-bank-payment-identity.svg) | [编辑源文件](e05-bank-payment-identity.mmd) |
| E06 外部执行与未知结果 | [查看](e06-external-state.svg) | [编辑源文件](e06-external-state.mmd) |
| E07 税评估、承诺与累计确认 | [查看](e07-tax-commitment.svg) | [编辑源文件](e07-tax-commitment.mmd) |
| E08 工资单发布与撤回 | [查看](e08-payslip-publication.svg) | [编辑源文件](e08-payslip-publication.mmd) |

<a id="跨模块流程"></a>

## 贯穿各层的业务流程

| 图 | SVG | Mermaid |
| --- | --- | --- |
| F01 招聘到首次工资 | [查看](f01-hire-first-pay.svg) | [编辑源文件](f01-hire-first-pay.mmd) |
| F02 调动与晋升调薪 | [查看](f02-transfer.svg) | [编辑源文件](f02-transfer.mmd) |
| F03 假勤到工资 | [查看](f03-time-payroll.svg) | [编辑源文件](f03-time-payroll.mmd) |
| F04 绩效到支付及财务 | [查看](f04-performance-to-finance.svg) | [编辑源文件](f04-performance-to-finance.mmd) |
| F05 历史更正与差额 | [查看](f05-retro-correction.svg) | [编辑源文件](f05-retro-correction.mmd) |
| F06 独立参缴闭环 | [查看](f06-contribution.svg) | [编辑源文件](f06-contribution.mmd) |
| F07 离职退休与再聘 | [查看](f07-exit-rehire.svg) | [编辑源文件](f07-exit-rehire.mmd) |
| F08 人才发展与任命 | [查看](f08-talent-development.svg) | [编辑源文件](f08-talent-development.mmd) |
| F09 可靠通知与消费者采用 | [查看](f09-reliable-delivery.svg) | [编辑源文件](f09-reliable-delivery.mmd) |

## 技术与部署视图

G04说明实现与部署选择，与上述业务阅读层级分别表达。

| 图 | SVG | Mermaid |
| --- | --- | --- |
| G04 正式技术与部署 | [查看](g04-formal-deployment.svg) | [源图](g04-formal-deployment.mmd) |

## 编辑与渲染

模块描述及图由人工编写的[data/business-modules.json](../data/business-modules.json)和[data/crosscutting-modules.json](../data/crosscutting-modules.json)格式化生成；概念矩阵由[data/concept-mapping.json](../data/concept-mapping.json)生成。[命令索引数据](../data/command-contract-index.json)只保存导航关系，生成16索引时从同一模块数据读取聚合归属。C/G/E/F图直接编辑对应Mermaid源文件。生成程序不推断功能完成度，SVG始终从源图渲染，不手工修改。

```bash
python3 -B docs/china-hcm/scripts/build_modules.py --dry-run
python3 -B docs/china-hcm/scripts/build_modules.py
node docs/china-hcm/scripts/render_diagrams.mjs --dry-run
node docs/china-hcm/scripts/render_diagrams.mjs \
  --cli-root /path/to/node_modules/@mermaid-js/mermaid-cli \
  --browser /path/to/chrome
node docs/china-hcm/scripts/inspect_diagrams.mjs \
  --cli-root /path/to/node_modules/@mermaid-js/mermaid-cli \
  --browser /path/to/chrome
python3 -B docs/china-hcm/scripts/validate_docs.py
```

渲染脚本使用已有Mermaid CLI 12.0.0和本机Chrome，不下载包、不为产品添加依赖。Noto Sans CJK SC字体由本机提供；SVG不嵌入字体，不包含脚本或foreignObject。字体在其他机器上可能回退。

[渲染清单](../data/render-manifest.json)保留源文件及SVG散列；[画布检查](../data/visual-geometry.json)保留浏览器、文本边界与被检图散列。`inspect_diagrams.mjs`支持`--dry-run`，也可用`--screenshots /path/to/review-output`保存人工复核缩略图；文本没有越出画布不等于已经排除所有遮挡。修改并重新渲染图后应重新检查；[验证记录](../06-evidence-and-validation.md)说明完成边界。文档渲染不构成产品业务测试。

### 文档CI

[GitHub Actions工作流](../../../.github/workflows/hcm-docs.yml)对docs变更运行离线验证及56项重新生成一致性检查；固定Python版本，官方[checkout](https://github.com/actions/checkout)及[setup-python](https://github.com/actions/setup-python)按已核对的v7提交固定，权限仅contents: read。没有CubeBox、Fusion或产品运行依赖。

CI核验模块/概念映射、命令与验收导航、生成字节、本地链接、SVG安全结构以及源图/产物/既有画布记录的散列一致性；它不重新渲染或执行浏览器，不代替语义和视觉复核。修改图源后须先本地渲染并检查，再提交SVG及记录。当前已验证本地等价命令，远端运行须实际推送后另看结果。

早期CubeBox文档的68个相邻工作区引用由[固定清单](../data/historical-workspace-links.json)保留；CI只核对清单，不声称这些外部目标存在。新增越界链接仍失败；需要本机核对时使用`python3 -B docs/china-hcm/scripts/validate_docs.py --check-historical-workspace`。

## 历史图纸

G01已从当前目录和统计移出，统一从[历史资料归档](../archive/README.md)访问。旧版本图纸封存在固定基线原件包中，不进入当前生成或渲染清单。
