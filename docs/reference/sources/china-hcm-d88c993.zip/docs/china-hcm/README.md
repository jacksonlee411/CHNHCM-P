# China HCM目标架构与设计

本专题面向中国大陆企业HCM，独立对标[HCM核心概念](../hcm/02-domain-model.md)，以**概念完整性、架构一致性和DDD原则**形成目标架构。20个业务模块、6项横向能力、17个限界上下文均按业务责任设计。CubeBox原型仅作为历史比较资料，不决定目标范围、核准机制或设计准入。

从[G02整体业务架构总图](diagrams/g02-target-domain-map.svg)开始，按[区域与概念图的对应表](02-target-architecture.md#1-整体模块架构)展开到C01—C05，再进入模块和关键设计。当前图集共53张目标设计图。历史原型运行图与旧资料已移入独立归档。

G02区分自助服务和专业办理入口，分别展示配置与权限支持、技术设施及分析消费者；人才任命与外部交换均标明所属域责任。连线语义和跨域边界见[总图说明](02-target-architecture.md#1-整体模块架构)。

2026-10-30按G02自上而下完成C01—C05逐项修订；领域概念、下级模块与流程图、DDD合同及映射同步更新。各阶段发现与独立闭合结果见[评审第6节](13-target-design-review.md)，当前验证边界见[证据页](06-evidence-and-validation.md)。

本轮进一步补充晋升调薪的分步完成、主选择覆盖、同日/跨夜衔接、M11/M13机构付款、薪酬口径、历史查询、影响闭环及编号/unknown处置。查看[命令与验收索引](16-command-acceptance-index.md)定位合同、聚合和AC01—AC10反例；采纳与复核记录见[评审第7节](13-target-design-review.md)。

## 自上而下的阅读入口

| 阅读层次 | 入口 | 回答的问题 |
| --- | --- | --- |
| L1 整体业务架构 | [G02总图](diagrams/g02-target-domain-map.svg)；[整体说明与展开关系](02-target-architecture.md) | 业务范围、模块分组及主要协作 |
| L2 领域概念架构 | 下表C01—C05；[概念架构说明](12-concept-architecture.md) | 核心概念、业务引用及来源关系 |
| L3 模块设计 | [M01—M20、X01—X06](#模块目录) | 模块主责、对象、规则及公开合同 |
| L4 关键设计 | [E系列对象与状态](diagrams/README.md#l4-关键对象聚合与状态设计)、[G06聚合与事务](diagrams/g06-aggregate-transactions.svg) | 关键不变量、聚合、状态和事务 |

L1—L4表示阅读颗粒度。G03/G05补充整体层的事实归属和DDD上下文；F系列以业务流程贯穿各层，G04单列技术部署。C05横向贯穿各业务域；招聘、服务和其他横向能力仍通过M05、M20、X系列继续展开，不能仅按五张C图判断全部模块的覆盖。

## 直接对标HCM颗粒度的概念图

| 主题 | 架构设计图 |
| --- | --- |
| 人员、工作关系、任职及全部业务引用 | [C01 核心人事概念](diagrams/c01-core-hcm-concepts.svg) |
| 法定/人员上下文、配置、计算、累计及输出 | [C02 薪资领域概念](diagrams/c02-payroll-concepts.svg) |
| 计划时间、实际工时、缺勤、权益与工资采用 | [C03 假勤概念](diagrams/c03-time-absence-concepts.svg) |
| 岗位要求、个人能力、评价、继任与学习发展 | [C04 人才概念](diagrams/c04-talent-concepts.svg) |
| 共享引用、适用范围、权限与领域核准 | [C05 引用与访问概念](diagrams/c05-reference-access-concepts.svg) |

## 目标设计文档

| 阅读目的 | 文档 |
| --- | --- |
| 术语、首选中文名称与业务定义 | [17 术语与定义](17-terminology-glossary.md) |
| 能力边界、事实主责、部署选择 | [02 整体目标架构](02-target-architecture.md) |
| 身份、日期、采用、资金与接口 | [03 一致性合同](03-consistency-contracts.md) |
| 主体、属地政策、税费及隐私建模 | [04 中国大陆设计](04-china-localization.md) |
| 独立设计取舍与验证顺序 | [05 目标路线](05-gap-and-roadmap.md) |
| 对标来源与验证边界 | [06 证据与验证](06-evidence-and-validation.md) |
| 131条参考概念的主责、处置及图节点 | [07 概念映射](07-concept-mapping.md) |
| 正常、异常及历史保护场景 | [08 联合流程](08-cross-module-flows.md) |
| 上下文、聚合、核准与事务不变量 | [10 DDD合同](10-ddd-and-state-contracts.md) |
| 与HCM同颗粒度的综合概念设计 | [12 概念架构](12-concept-architecture.md) |
| 目标设计语义评审依据 | [13 目标设计评审](13-target-design-review.md) |
| 历史隔离与原件保全 | [15 归档整理记录](15-archive-transition.md) |
| 模块同源的对象/聚合/写端口目录 | [14 聚合目录](14-aggregate-catalog.md) |
| 命令、事务合同、恢复与后续验收 | [16 同源命令与验收索引](16-command-acceptance-index.md) |
| 全部SVG和Mermaid | [图集索引](diagrams/README.md) |

<a id="模块目录"></a>

## 模块设计入口

| 模块 | 业务职责 | 设计说明 | 架构图 |
| --- | --- | --- | --- |
| M01 | 人员身份与个人资料 | [阅读](modules/m01.md) | [SVG](diagrams/m01.svg) / [源图](diagrams/m01.mmd) |
| M02 | 企业、组织与地点 | [阅读](modules/m02.md) | [SVG](diagrams/m02.svg) / [源图](diagrams/m02.mmd) |
| M03 | 职务、职级、职位与编制 | [阅读](modules/m03.md) | [SVG](diagrams/m03.svg) / [源图](diagrams/m03.mmd) |
| M04 | 用工、任职与劳动合同 | [阅读](modules/m04.md) | [SVG](diagrams/m04.svg) / [源图](diagrams/m04.mmd) |
| M05 | 招聘、录用与入职协同 | [阅读](modules/m05.md) | [SVG](diagrams/m05.svg) / [源图](diagrams/m05.mmd) |
| M06 | 排班与工时制度 | [阅读](modules/m06.md) | [SVG](diagrams/m06.svg) / [源图](diagrams/m06.mmd) |
| M07 | 考勤与实际工时 | [阅读](modules/m07.md) | [SVG](diagrams/m07.svg) / [源图](diagrams/m07.mmd) |
| M08 | 休假、缺勤与权益账户 | [阅读](modules/m08.md) | [SVG](diagrams/m08.svg) / [源图](diagrams/m08.mmd) |
| M09 | 薪酬体系、定薪与激励 | [阅读](modules/m09.md) | [SVG](diagrams/m09.svg) / [源图](diagrams/m09.mmd) |
| M10 | 工资核算、累计与追溯 | [阅读](modules/m10.md) | [SVG](diagrams/m10.svg) / [源图](diagrams/m10.mmd) |
| M11 | 个人所得税扣缴与申报 | [阅读](modules/m11.md) | [SVG](diagrams/m11.svg) / [源图](diagrams/m11.mmd) |
| M12 | 社会保险与住房公积金 | [阅读](modules/m12.md) | [SVG](diagrams/m12.svg) / [源图](diagrams/m12.mmd) |
| M13 | 企业福利 | [阅读](modules/m13.md) | [SVG](diagrams/m13.svg) / [源图](diagrams/m13.mmd) |
| M14 | 工资支付与银行用途 | [阅读](modules/m14.md) | [SVG](diagrams/m14.svg) / [源图](diagrams/m14.mmd) |
| M15 | 人工成本与财务衔接 | [阅读](modules/m15.md) | [SVG](diagrams/m15.svg) / [源图](diagrams/m15.mmd) |
| M16 | 人才档案、技能与资格 | [阅读](modules/m16.md) | [SVG](diagrams/m16.svg) / [源图](diagrams/m16.mmd) |
| M17 | 目标与绩效 | [阅读](modules/m17.md) | [SVG](diagrams/m17.svg) / [源图](diagrams/m17.mmd) |
| M18 | 学习与发展 | [阅读](modules/m18.md) | [SVG](diagrams/m18.svg) / [源图](diagrams/m18.mmd) |
| M19 | 人才盘点、人才池与继任 | [阅读](modules/m19.md) | [SVG](diagrams/m19.svg) / [源图](diagrams/m19.mmd) |
| M20 | 员工经理服务与HR任务 | [阅读](modules/m20.md) | [SVG](diagrams/m20.svg) / [源图](diagrams/m20.mmd) |
| X01 | 身份、有效期、修订与采用历史 | [阅读](modules/x01.md) | [SVG](diagrams/x01.svg) / [源图](diagrams/x01.mmd) |
| X02 | 共享配置、适用范围、默认与政策版本 | [阅读](modules/x02.md) | [SVG](diagrams/x02.svg) / [源图](diagrams/x02.mmd) |
| X03 | 身份权限与隐私 | [阅读](modules/x03.md) | [SVG](diagrams/x03.svg) / [源图](diagrams/x03.mmd) |
| X04 | 任务、作业与人工核对 | [阅读](modules/x04.md) | [SVG](diagrams/x04.svg) / [源图](diagrams/x04.mmd) |
| X05 | 导入导出与外部集成 | [阅读](modules/x05.md) | [SVG](diagrams/x05.svg) / [源图](diagrams/x05.mmd) |
| X06 | 报表、指标与事实追溯 | [阅读](modules/x06.md) | [SVG](diagrams/x06.svg) / [源图](diagrams/x06.mmd) |

## 设计证据与历史资料

[D]表示本目标设计，[O]表示有版本边界的官方概念来源。历史源码和台账统一存放于归档。目标完整性按概念、关系、事实主责、聚合和场景检查，不以原型实现程度或图数衡量。政策范围和实际运行验证另行记录。

历史资料集中在[归档目录](archive/README.md)，包括原型观察、G01、26模块原型对照和旧评审。当前正文及图集不再并列展示这些材料。旧记录只证明其固定基线，原件包与阅读版、缺失输入和可恢复范围分别标明。
