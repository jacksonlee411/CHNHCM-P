'use client';
import * as React from 'react';
import type { RefObject } from '@mui/x-internals/types';
import type { GridPrivateApiCommon } from '../../models/api/gridApiCommon';
import type { GridPrivateApiCommunity } from '../../models/api/gridApiCommunity';
import type { DataGridProcessedProps } from '../../models/props/DataGridProps';

type DeepPartial<T> = {
  [P in keyof T]?: DeepPartial<T[P]>;
};

export type GridStateInitializer<
  P extends Partial<DataGridProcessedProps> = DataGridProcessedProps,
  PrivateApi extends GridPrivateApiCommon = GridPrivateApiCommunity,
> = (
  state: DeepPartial<PrivateApi['state']>,
  props: P,
  privateApiRef: RefObject<PrivateApi>,
) => DeepPartial<PrivateApi['state']>;

export const useGridInitializeState = <
  P extends Partial<DataGridProcessedProps>,
  PrivateApi extends GridPrivateApiCommon = GridPrivateApiCommunity,
>(
  initializer: GridStateInitializer<P, PrivateApi>,
  privateApiRef: RefObject<PrivateApi>,
  props: P,
  key?: string,
) => {
  const previousKey = React.useRef<string | undefined>(key);
  const isInitialized = React.useRef(false);

  if (key !== previousKey.current) {
    isInitialized.current = false;
    previousKey.current = key;
  }

  if (!isInitialized.current) {
    privateApiRef.current.state = initializer(
      privateApiRef.current.state,
      props,
      privateApiRef,
    ) as PrivateApi['state'];
    isInitialized.current = true;
  }
};
