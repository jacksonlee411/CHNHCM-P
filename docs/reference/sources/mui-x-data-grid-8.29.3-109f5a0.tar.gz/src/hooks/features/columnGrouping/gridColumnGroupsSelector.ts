import {
  createSelector,
  createRootSelector,
  createSelectorMemoized,
} from '../../../utils/createSelector';
import type { GridStateCommunity } from '../../../models/gridStateCommunity';

/**
 * @category ColumnGrouping
 * @ignore - do not document.
 */
export const gridColumnGroupingSelector = createRootSelector(
  (state: GridStateCommunity) => state.columnGrouping,
);

export const gridColumnGroupsUnwrappedModelSelector = createSelectorMemoized(
  gridColumnGroupingSelector,
  (columnGrouping) => columnGrouping?.unwrappedGroupingModel ?? {},
);

export const gridColumnGroupsLookupSelector = createSelectorMemoized(
  gridColumnGroupingSelector,
  (columnGrouping) => columnGrouping?.lookup ?? {},
);

export const gridColumnGroupsHeaderStructureSelector = createSelectorMemoized(
  gridColumnGroupingSelector,
  (columnGrouping) => columnGrouping?.headerStructure ?? [],
);

export const gridColumnGroupsHeaderMaxDepthSelector = createSelector(
  gridColumnGroupingSelector,
  (columnGrouping) => columnGrouping?.maxDepth ?? 0,
);
