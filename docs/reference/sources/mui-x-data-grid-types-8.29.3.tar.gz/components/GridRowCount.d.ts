import * as React from 'react';
import { type SxProps, type Theme } from '@mui/system';
interface RowCountProps {
  rowCount: number;
  visibleRowCount: number;
}
export type GridRowCountProps = React.HTMLAttributes<HTMLDivElement> & RowCountProps & {
  sx?: SxProps<Theme>;
};
declare const GridRowCount: React.ForwardRefExoticComponent<GridRowCountProps> | React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & RowCountProps & {
  sx?: SxProps<Theme>;
} & React.RefAttributes<HTMLDivElement>>;
export { GridRowCount };