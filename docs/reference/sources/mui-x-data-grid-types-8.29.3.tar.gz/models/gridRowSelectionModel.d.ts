import type { GridRowId } from "./gridRows.js";
export type GridRowSelectionPropagation = {
  descendants?: boolean;
  parents?: boolean;
};
export type GridRowSelectionModel = {
  type: 'include' | 'exclude';
  ids: Set<GridRowId>;
};