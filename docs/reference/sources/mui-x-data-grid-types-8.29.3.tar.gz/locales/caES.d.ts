import { type Localization } from "../utils/getGridLocalization.js";
export declare const caES: Localization;